# Bot Dashboard — Clean Source

This is the source code for the bot monitoring website and its API service.
It intentionally does not include `node_modules`, build output, Vite caches,
TypeScript cache files, database credentials, or live API keys.

## Included

- `artifacts/bot-dashboard` — the website UI
- `artifacts/api-server` — the API that receives bot pings and serves telemetry
- `lib/api-client-react` — generated client used by the website
- `lib/api-zod` — API validation schemas
- `lib/db` — database schema and connection code
- `lib/api-spec` — OpenAPI contract and code generation config

## Run locally

1. Install Node.js and pnpm.
2. Create a PostgreSQL database and set `DATABASE_URL` in your environment.
3. Run `pnpm install`.
4. Push the schema with `pnpm --filter @workspace/db run push`.
5. Start the API with `pnpm --filter @workspace/api-server run dev`.
6. Start the website with `PORT=3000 BASE_PATH=/ pnpm --filter @workspace/bot-dashboard run dev`.

The website expects the API at `/api` through the same host or reverse proxy.

## Bot connection

Bots send authenticated `POST` requests to `/api/bots/<BOT_ID>/ping` with an
`X-API-Key` header. API keys are stored in the database and are intentionally
not included in this download.
