# Bot Integration Template

Keep each API key in your bot's private environment variables or secret store.
Do not commit keys to source control or place them in a public download.

```bash
curl -X POST https://YOUR_DOMAIN/api/bots/BOT_ID/ping \\
  -H "X-API-Key: YOUR_BOT_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"status":"online","messagesProcessed":0,"commandsHandled":0,"errorsToday":0}'
```

Valid statuses are `online`, `offline`, `error`, and `starting`.
Send a ping about every 30–60 seconds to keep the dashboard current.
